package com.example.cybertrackernative.data

import androidx.room.*

@Dao
interface CyberDao {
    @Insert fun insertYear(y: YearEntity): Long
    @Insert fun insertArea(a: AreaEntity): Long
    @Insert fun insertModule(m: ModuleEntity): Long
    @Insert fun insertTask(t: TaskEntity): Long
    @Insert fun insertLog(l: StudyLogEntity): Long

    @Query("SELECT * FROM years") fun getYears(): List<YearEntity>
    @Query("SELECT * FROM areas WHERE yearId=:yearId") fun getAreas(yearId: Long): List<AreaEntity>
    @Query("SELECT * FROM modules WHERE areaId=:areaId") fun getModules(areaId: Long): List<ModuleEntity>
    @Query("SELECT * FROM tasks WHERE moduleId=:moduleId") fun getTasks(moduleId: Long): List<TaskEntity>
    @Query("SELECT * FROM logs WHERE taskId=:taskId ORDER BY id DESC") fun getLogs(taskId: Long): List<StudyLogEntity>

    @Transaction
    @Query("SELECT * FROM tasks WHERE id=:taskId")
    fun getTaskWithLogs(taskId: Long): List<TaskWithLogs>

    @Query("UPDATE tasks SET isDone=:isDone WHERE id=:taskId")
    fun setTaskDone(taskId: Long, isDone: Boolean)

    @Query("SELECT COUNT(*) FROM tasks") fun countTasks(): Int
    @Query("SELECT COUNT(*) FROM tasks WHERE isDone=1") fun countDone(): Int
}