package com.example.cybertrackernative

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.cybertrackernative.data.CyberDb
import com.example.cybertrackernative.data.Repo
import com.example.cybertrackernative.ui.screens.*
import com.example.cybertrackernative.ui.theme.AppTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                val nav = rememberNavController()
                var ready by remember { mutableStateOf(false) }
                val dao = remember { CyberDb.get(this@MainActivity).dao() }

                LaunchedEffect(Unit) {
                    withContext(Dispatchers.IO) { Repo.ensureSeed(this@MainActivity) }
                    ready = true
                }

                if (!ready) Surface { Text("Loading...") }
                else NavHost(navController = nav, startDestination = "home") {
                    composable("home") { HomeScreen(nav, dao) }
                    composable("areas") { AreasScreen(nav, dao) }
                    composable("modules/{areaId}") { back ->
                        val areaId = back.arguments?.getString("areaId")!!.toLong()
                        ModulesScreen(nav, dao, areaId)
                    }
                    composable("tasks/{modId}") { back ->
                        val modId = back.arguments?.getString("modId")!!.toLong()
                        TasksScreen(nav, dao, modId)
                    }
                    composable("task/{taskId}") { back ->
                        val taskId = back.arguments?.getString("taskId")!!.toLong()
                        TaskScreen(nav, dao, taskId)
                    }
                    composable("stats") { StatsScreen(dao) }
                }
            }
        }
    }
}