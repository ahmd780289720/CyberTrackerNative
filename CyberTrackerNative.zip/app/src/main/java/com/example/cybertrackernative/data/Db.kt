package com.example.cybertrackernative.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [YearEntity::class, AreaEntity::class, ModuleEntity::class, TaskEntity::class, StudyLogEntity::class], version = 1)
abstract class CyberDb : RoomDatabase() {
    abstract fun dao(): CyberDao

    companion object {
        @Volatile private var INSTANCE: CyberDb? = null
        fun get(context: Context): CyberDb =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(context, CyberDb::class.java, "cybertracker.db").build().also { INSTANCE = it }
            }
    }
}