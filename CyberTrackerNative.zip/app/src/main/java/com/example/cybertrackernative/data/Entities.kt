package com.example.cybertrackernative.data

import androidx.room.*

@Entity(tableName = "years")
data class YearEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String
)

@Entity(
    tableName = "areas",
    foreignKeys = [ForeignKey(entity = YearEntity::class, parentColumns = ["id"], childColumns = ["yearId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("yearId")]
)
data class AreaEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val yearId: Long,
    val name: String
)

@Entity(
    tableName = "modules",
    foreignKeys = [ForeignKey(entity = AreaEntity::class, parentColumns = ["id"], childColumns = ["areaId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("areaId")]
)
data class ModuleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val areaId: Long,
    val name: String
)

@Entity(
    tableName = "tasks",
    foreignKeys = [ForeignKey(entity = ModuleEntity::class, parentColumns = ["id"], childColumns = ["moduleId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("moduleId")]
)
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val moduleId: Long,
    val name: String,
    val isDone: Boolean = false
)

@Entity(
    tableName = "logs",
    foreignKeys = [ForeignKey(entity = TaskEntity::class, parentColumns = ["id"], childColumns = ["taskId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("taskId")]
)
data class StudyLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: Long,
    val minutes: Int,
    val note: String?,
    val at: String
)

data class TaskWithLogs(
    @Embedded val task: TaskEntity,
    @Relation(parentColumn = "id", entityColumn = "taskId")
    val logs: List<StudyLogEntity>
)