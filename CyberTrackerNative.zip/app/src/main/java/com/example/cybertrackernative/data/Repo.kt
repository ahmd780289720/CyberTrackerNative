package com.example.cybertrackernative.data

import android.content.Context
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

object Repo {
    suspend fun ensureSeed(context: Context) {
        val db = CyberDb.get(context)
        if (db.dao().countTasks() > 0) return

        val json = context.assets.open("seed.json").bufferedReader().use { it.readText() }
        val type = object: TypeToken<Map<String, Any>>(){}.type
        val map: Map<String, Any> = Gson().fromJson(json, type)
        val years = map["years"] as List<*>

        val dao = db.dao()
        db.runInTransaction {
            years.forEach { yAny ->
                val y = yAny as Map<*,*>
                val yId = dao.insertYear(YearEntity(name = y["name"] as String))
                val areas = y["areas"] as List<*>
                areas.forEach { aAny ->
                    val a = aAny as Map<*,*>
                    val aId = dao.insertArea(AreaEntity(yearId = yId, name = a["name"] as String))
                    val modules = a["modules"] as List<*>
                    modules.forEach { mAny ->
                        val m = mAny as Map<*,*>
                        val mId = dao.insertModule(ModuleEntity(areaId = aId, name = m["name"] as String))
                        val tasks = m["tasks"] as List<*>
                        tasks.forEach { tAny ->
                            val t = tAny as String
                            dao.insertTask(TaskEntity(moduleId = mId, name = t, isDone = false))
                        }
                    }
                }
            }
        }
    }
}