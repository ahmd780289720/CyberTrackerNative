Build with GitHub Actions: push repo then run workflow; download APK from Artifacts.
